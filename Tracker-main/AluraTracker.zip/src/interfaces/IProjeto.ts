export default interface IProjeto {
    id: string;
    nome: string;
}